'use strict';
var express = require('express');
var app = express();



const WC = require('./node_modules/woocommerce/lib/woocommerce');

const wc1 = new WC({
  url: 'http://harborcity.top/sfood',
  ssl: false,
  consumerKey: 'ck_85abe624e16dd56f30da1170e2b50f1291e27a41',
  secret: 'cs_85424c0bb696e0ea3a58d3a86623b5c0cddf6f75'
});

var server = app.listen(8082, function () {

  var host = server.address().address
  var port = server.address().port

  console.log("Example app listening at http://%s:%s", host, port)

})
app.get('/products', function (req, res) {
   console.log(req.url);
   wc1.get(req.url).
   then(function(p){

    // console.log(p.products);
 res.json(p.products);
 }).
 catch(console.error);
})

// app.get('/products/', function (req, res) {
//    wc1.get('/products').
//    then(function(p){
//
//      console.log(p.products);
//  res.json(p.products);
//  }).
//  catch(console.error);
// })

app.get('/products/categories', function (req, res) {
   wc1.get('/products/categories').
   then(function(p){

     console.log(p.product_categories);
 res.json(p.product_categories);
 }).
 catch(console.error);
})


//wc1.get('/products').then(p => console.log(p.length)).catch(console.error);
